﻿// ================================================================= 0.9.0 =====
// Tingen Lieutenant: A class library for Tingen Commander
// Repository: https://github.com/spectrum-health-systems/Tingen-Lieutenant
// Documentation: https://github.com/spectrum-health-systems/Tingen-Documentation
// Copyright (c) A Pretty Cool Program. All rights reserved.
// Licensed under the Apache 2.0 license.
// ================================================================ 241217 =====

// u241217.1130_code
// u241217_documentation

namespace TingenLieutenant
{
    public class WelcomeToTingenLieutenant
    {

    }
}
